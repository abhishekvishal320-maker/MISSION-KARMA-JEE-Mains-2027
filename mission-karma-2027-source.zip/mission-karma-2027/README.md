# MISSION KARMA 2027

A local-first JEE Main preparation planner delivered from one React + Vite codebase as both an installable PWA and a Capacitor Android app.

## Included

- Dashboard with phase countdown, JEE Main deadline countdown, subject progress and weekly study hours.
- Sequential study phases: 20 Nov–2 Dec 2026 concepts/notes; 3–15 Dec PYQs/revision; 16–28 Dec mocks/FTS; 29–31 Dec buffer; 1–15 Jan 2027 full-syllabus mocks. The next phase becomes active automatically on its start date.
- Physics, Chemistry and Mathematics chapter tracker separated into Class 11 and 12, with editable A/B/C priorities and completion status.
- Focus timer with subject/task labels and saved study sessions.
- Calendar heatmap based on recorded study time.
- Test-result tracker for chapter tests, Abhyas, PYQs, FTS and full mocks.
- Notes/formula vault with locally stored text and optional image attachment.
- Local JSON backup and restore.

## Requirements

- Node.js 20 or newer and npm.
- For local Android builds: Android Studio, Android SDK and Java 21.
- For GitHub Actions Android builds: GitHub account; Actions enabled.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. For production:

```bash
npm run build
npm run preview
```

## Publish the PWA with GitHub Pages

1. Create a new GitHub repository named `mission-karma-2027`.
2. Upload/push the complete contents of this folder to the repository's `main` branch (including `.github`).
3. In GitHub, open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
4. Open **Actions → Deploy PWA to GitHub Pages** and run it, or push a commit to `main`.
5. When deployment finishes, open the Pages URL shown in the workflow summary on Android Chrome.
6. In Chrome, tap **⋮ → Install app** (or **Add to Home screen**) and confirm.

The Vite build uses relative asset paths, so it works from a GitHub project Pages URL.

## Build and download the Android APK

1. Push this project to the same GitHub repository on branch `main`.
2. Open **Actions → Build Android APK**.
3. Select **Run workflow** if it has not already run after a push.
4. Wait for the green successful run.
5. Open that run, scroll to **Artifacts**, and download `mission-karma-2027-debug-apk`.
6. Extract the ZIP and install `app-debug.apk` on your Android device. Android may ask you to allow installation from the browser/file manager you used. Only install APKs you built from your own repository.

This workflow creates a debug APK suitable for personal testing. A public Play Store release requires a signed release build, signing key management and Play Console setup; do not publish the debug APK as a production release.

## Local Android build (optional)

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Build a debug APK from Android Studio, or run:

```bash
cd android
./gradlew assembleDebug
```

Output: `android/app/build/outputs/apk/debug/app-debug.apk`.

## Data, privacy and backups

All progress is saved in the app's local browser storage on the device. The PWA and APK do not sync data between each other or between devices. Export a JSON backup from **Settings → Backup & restore** before clearing site data, uninstalling the app or changing phones. Restore the JSON backup on the destination installation.

The notes screen stores the image and text supplied by the user. It does not claim to perform AI/OCR extraction; that requires a separately configured AI service and network access.

## Important syllabus note

The initial chapter list is a broad editable planning baseline, not a guarantee of the official JEE Main 2027 syllabus. NTA syllabus coverage can change. Verify chapter inclusion against the official 2027 information bulletin and edit the tracker as needed. The app deliberately does not fabricate PYQ/mock URLs or claim a live question bank.

## Troubleshooting

- **`npm install` fails:** use Node 20+ and commit the generated `package-lock.json` together with `package.json`.
- **Pages shows 404:** ensure Pages source is GitHub Actions, the deployment workflow succeeded, and open the exact URL from the deployment summary.
- **Install app option missing:** use Chrome on Android, open the deployed HTTPS URL, and wait for the page to finish loading once.
- **APK workflow fails at Gradle/Java:** check the Actions log; the workflow configures Java 21 and generates the Capacitor Android project during the build.
- **Progress disappears:** browser/app data may have been cleared. Restore your latest JSON backup.
